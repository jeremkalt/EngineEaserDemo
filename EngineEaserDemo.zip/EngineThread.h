#pragma once
// demo code by J. Kaltenmark

#include <thread>
#include <condition_variable>
#include <mutex>
#include <chrono>

using namespace std::chrono;
#define TimeNow std::chrono::high_resolution_clock::now
typedef std::chrono::duration<double, std::milli> Duration;

class EngineThread
{
public:
    EngineThread(const char* name, bool autoStart = false)
        : m_Name(name)
    {
        if(autoStart)
            StartThread();
    }

    virtual ~EngineThread()
    {
        StopThread();
    }

    void StartThread()
    {        
        m_thread = std::thread(&EngineThread::RunInternal, this);
        std::unique_lock<std::mutex> locker (m_startMutex);
        m_cv.wait(locker);
        m_Run = true;
    }

    void Join() 
    {
        if(m_thread.joinable())
            m_thread.join();
    }

    void StopThreadWithoutJoining()
    {
        m_Run = false;
    }

    void StopThread()
    {
        m_Run = false;
        Join();
    }

    virtual void Run () = 0;

    bool isStarted()
    {
        return m_Run;
    }

private: 
    void RunInternal () 
    {
        m_cv.notify_one();
        Run();
    }

protected:
    std::mutex m_startMutex;
    volatile bool m_Run;

private: 
    std::condition_variable m_cv;
    std::thread m_thread;
    const char* m_Name;
};