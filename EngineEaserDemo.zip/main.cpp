// demo code by J. Kaltenmark


#include <iostream>
#include "GameEngine.h"

int main()
{
    std::cout << " -- Easer Engine --\n";

	GameEngine engine;
	while (engine.isStarted())
	{
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}

}
